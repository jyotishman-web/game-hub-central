export interface Game {
  id: string;
  title: string;
  description: string;
  category: string;
  thumbnail: string;
  /** Path to the HTML file in /public/games/ */
  path: string;
  featured?: boolean;
}

export const categories = [
  "All",
  "Action",
  "Puzzle",
  "Arcade",
  "Racing",
  "Sports",
  "Strategy",
] as const;

export type Category = (typeof categories)[number];

/**
 * ADD YOUR GAMES HERE
 * 
 * To add a new game:
 * 1. Put your HTML game file in /public/games/your-game/index.html
 * 2. Add a thumbnail image in /public/games/your-game/thumb.png (or use a URL)
 * 3. Add an entry below
 */
export const games: Game[] = [
  {
    id: "snake",
    title: "Snake Classic",
    description: "The classic snake game. Eat food, grow longer, don't hit yourself!",
    category: "Arcade",
    thumbnail: "/games/snake/thumb.png",
    path: "/games/snake/index.html",
    featured: true,
  },
  {
    id: "tetris",
    title: "Block Drop",
    description: "Stack falling blocks and clear lines in this timeless puzzle game.",
    category: "Puzzle",
    thumbnail: "/games/tetris/thumb.png",
    path: "/games/tetris/index.html",
    featured: true,
  },
  {
    id: "pong",
    title: "Pong",
    description: "Classic 2-player pong. Challenge yourself against the AI!",
    category: "Sports",
    thumbnail: "/games/pong/thumb.png",
    path: "/games/pong/index.html",
  },
  {
    id: "tic-tac-toe",
    title: "Tic Tac Toe",
    description: "The classic X and O game. Play against a friend on the same screen!",
    category: "Puzzle",
    thumbnail: "/games/tic-tac-toe/thumb.png",
    path: "/games/Tic tac toe  /index.html",
    featured: true,
  },
];
