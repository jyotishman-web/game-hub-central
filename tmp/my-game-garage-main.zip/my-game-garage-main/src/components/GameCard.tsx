import { Link } from "react-router-dom";
import { Play } from "lucide-react";
import type { Game } from "@/data/games";

interface GameCardProps {
  game: Game;
  index?: number;
}

const GameCard = ({ game, index = 0 }: GameCardProps) => {
  return (
    <Link
      to={`/play/${game.id}`}
      className="group relative block rounded-lg overflow-hidden bg-card border border-border game-card-hover animate-fade-in"
      style={{ animationDelay: `${index * 80}ms`, animationFillMode: "both" }}
    >
      {/* Thumbnail */}
      <div className="aspect-video bg-secondary relative overflow-hidden">
        <img
          src={game.thumbnail}
          alt={game.title}
          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
          onError={(e) => {
            e.currentTarget.style.display = "none";
            e.currentTarget.nextElementSibling?.classList.remove("hidden");
          }}
        />
        <div className="hidden absolute inset-0 flex items-center justify-center bg-muted">
          <span className="font-display text-2xl text-primary/40 select-none">{game.title[0]}</span>
        </div>
        {/* Play overlay */}
        <div className="absolute inset-0 flex items-center justify-center bg-background/60 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
          <div className="w-14 h-14 rounded-full bg-primary flex items-center justify-center shadow-lg shadow-primary/30 transition-transform duration-300 group-hover:scale-110">
            <Play className="h-6 w-6 text-primary-foreground ml-0.5" />
          </div>
        </div>
      </div>

      {/* Info */}
      <div className="p-3">
        <h3 className="font-display text-sm font-semibold text-foreground truncate">
          {game.title}
        </h3>
        <p className="text-xs text-muted-foreground mt-1 line-clamp-2">
          {game.description}
        </p>
        <span className="inline-block mt-2 text-[10px] font-semibold uppercase tracking-wider text-primary bg-primary/10 px-2 py-0.5 rounded-full">
          {game.category}
        </span>
      </div>
    </Link>
  );
};

export default GameCard;
