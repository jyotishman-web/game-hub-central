import { Link } from "react-router-dom";
import { Gamepad2 } from "lucide-react";

const Header = () => {
  return (
    <header className="sticky top-0 z-50 border-b border-border bg-background/80 backdrop-blur-md">
      <div className="container flex items-center justify-between h-16">
        <Link to="/" className="flex items-center gap-2.5 group">
          <Gamepad2 className="h-7 w-7 text-primary group-hover:animate-pulse-neon" />
          <span className="font-display text-xl font-bold tracking-wide text-foreground">
            GAME<span className="text-primary neon-text">HUB</span>
          </span>
        </Link>
        <nav className="hidden sm:flex items-center gap-6 text-sm font-medium text-muted-foreground">
          <Link to="/" className="hover:text-primary transition-colors">Home</Link>
        </nav>
      </div>
    </header>
  );
};

export default Header;
