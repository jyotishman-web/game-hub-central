import { useParams, Link, Navigate } from "react-router-dom";
import { ArrowLeft, Maximize, Minimize } from "lucide-react";
import { games } from "@/data/games";
import { useState } from "react";

const PlayGame = () => {
  const { gameId } = useParams<{ gameId: string }>();
  const game = games.find((g) => g.id === gameId);
  const [fullscreen, setFullscreen] = useState(false);

  if (!game) return <Navigate to="/" replace />;

  return (
    <div className={`min-h-screen bg-background flex flex-col ${fullscreen ? "" : ""}`}>
      {/* Top bar */}
      {!fullscreen && (
        <div className="border-b border-border bg-card">
          <div className="container flex items-center justify-between h-14">
            <Link
              to="/"
              className="flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors"
            >
              <ArrowLeft className="h-4 w-4" />
              Back to Games
            </Link>
            <h1 className="font-display text-sm font-bold text-foreground">
              {game.title}
            </h1>
            <button
              onClick={() => setFullscreen(true)}
              className="flex items-center gap-1.5 text-sm text-muted-foreground hover:text-primary transition-colors"
            >
              <Maximize className="h-4 w-4" />
              <span className="hidden sm:inline">Fullscreen</span>
            </button>
          </div>
        </div>
      )}

      {/* Game iframe */}
      <div className={`flex-1 flex items-center justify-center ${fullscreen ? "fixed inset-0 z-50 bg-background" : "container py-6"}`}>
        {fullscreen && (
          <button
            onClick={() => setFullscreen(false)}
            className="absolute top-4 right-4 z-10 p-2 rounded-lg bg-card/80 backdrop-blur border border-border text-muted-foreground hover:text-foreground transition-colors"
          >
            <Minimize className="h-5 w-5" />
          </button>
        )}
        <iframe
          src={game.path}
          title={game.title}
          className={`border border-border rounded-lg bg-card ${
            fullscreen ? "w-full h-full rounded-none border-none" : "w-full max-w-4xl aspect-video"
          }`}
          sandbox="allow-scripts allow-same-origin"
        />
      </div>

      {/* Game info */}
      {!fullscreen && (
        <div className="container pb-10">
          <div className="max-w-4xl mx-auto">
            <span className="inline-block text-[10px] font-semibold uppercase tracking-wider text-primary bg-primary/10 px-2 py-0.5 rounded-full">
              {game.category}
            </span>
            <p className="mt-2 text-muted-foreground text-sm">
              {game.description}
            </p>
          </div>
        </div>
      )}
    </div>
  );
};

export default PlayGame;
