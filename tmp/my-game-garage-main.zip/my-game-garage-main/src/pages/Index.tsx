import { useState, useMemo } from "react";
import Header from "@/components/Header";
import SearchBar from "@/components/SearchBar";
import CategoryFilter from "@/components/CategoryFilter";
import GameCard from "@/components/GameCard";
import { games, type Category } from "@/data/games";
import { Gamepad2 } from "lucide-react";

const Index = () => {
  const [search, setSearch] = useState("");
  const [category, setCategory] = useState<Category>("All");

  const filtered = useMemo(() => {
    return games.filter((g) => {
      const matchCat = category === "All" || g.category === category;
      const matchSearch =
        !search ||
        g.title.toLowerCase().includes(search.toLowerCase()) ||
        g.description.toLowerCase().includes(search.toLowerCase());
      return matchCat && matchSearch;
    });
  }, [search, category]);

  const featured = games.filter((g) => g.featured);

  return (
    <div className="min-h-screen bg-background">
      <Header />

      {/* Hero */}
      <section className="container py-12 md:py-20">
        <div className="text-center max-w-2xl mx-auto animate-fade-in">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-primary/10 border border-primary/20 mb-6">
            <Gamepad2 className="h-4 w-4 text-primary" />
            <span className="text-xs font-semibold uppercase tracking-wider text-primary">
              Play Instantly
            </span>
          </div>
          <h1 className="text-4xl md:text-6xl font-display font-black tracking-tight text-foreground">
            Your Games,{" "}
            <span className="text-primary neon-text">One Place</span>
          </h1>
          <p className="mt-4 text-muted-foreground text-lg max-w-lg mx-auto">
            A curated collection of HTML games ready to play right in your browser. No downloads, no installs.
          </p>

          {/* Search bar moved to hero */}
          <div className="mt-8 flex justify-center">
            <SearchBar value={search} onChange={setSearch} />
          </div>
        </div>
      </section>

      {/* Featured */}
      {featured.length > 0 && (
        <section className="container pb-10">
          <h2 className="font-display text-lg font-bold text-foreground mb-4 animate-fade-in">
            ⭐ Featured
          </h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
            {featured.map((game, i) => (
              <GameCard key={game.id} game={game} index={i} />
            ))}
          </div>
        </section>
      )}

      {/* All Games */}
      <section className="container pb-20">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-6">
          <h2 className="font-display text-lg font-bold text-foreground animate-fade-in">
            All Games
          </h2>
        </div>

        <CategoryFilter selected={category} onSelect={setCategory} />

        {filtered.length > 0 ? (
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4 mt-6">
            {filtered.map((game, i) => (
              <GameCard key={game.id} game={game} index={i} />
            ))}
          </div>
        ) : (
          <div className="flex flex-col items-center justify-center py-20 text-muted-foreground animate-fade-in">
            <Gamepad2 className="h-12 w-12 mb-3 opacity-30" />
            <p className="text-sm">No games found</p>
          </div>
        )}
      </section>
    </div>
  );
};

export default Index;
